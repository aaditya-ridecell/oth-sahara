from django.apps import AppConfig


class TreasurehuntConfig(AppConfig):
    name = 'treasurehunt'
